import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import Link from "next/link"
import {
    LayoutDashboard,
    Users,
    FileText,
    Settings,
    LogOut,
    PlusCircle,
} from "lucide-react"

import { prisma } from "@/lib/prisma"
import { getCurrentProfileId } from "@/lib/currentProfile"
import { ProfileSwitcher } from "@/components/ProfileSwitcher"

export default async function DashboardLayout({
    children,
}: {
    children: React.ReactNode
}) {
    const session = await getServerSession(authOptions)

    if (!session) {
        redirect("/auth/login")
    }

    const userId = parseInt(session.user.id)
    const profiles = await prisma.companyProfile.findMany({
        where: { userId },
        orderBy: { name: "asc" }
    })
    const currentProfileId = await getCurrentProfileId()

    return (
        <div className="flex h-screen bg-muted/20">
            {/* Sidebar */}
            <aside className="w-64 bg-card border-r hidden md:flex flex-col">
                <div className="p-6 border-b">
                    <h1 className="text-xl font-bold tracking-tight">Invoicer</h1>
                    <div className="mt-4">
                        <ProfileSwitcher profiles={profiles} currentProfileId={currentProfileId} />
                    </div>
                </div>
                <nav className="flex-1 p-4 space-y-1">
                    <Link
                        href="/dashboard"
                        className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted text-foreground"
                    >
                        <LayoutDashboard className="h-4 w-4" />
                        Dashboard
                    </Link>
                    <Link
                        href="/dashboard/invoices/new"
                        className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted text-foreground"
                    >
                        <PlusCircle className="h-4 w-4" />
                        New Invoice
                    </Link>
                    <Link
                        href="/dashboard/invoices"
                        className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted text-foreground"
                    >
                        <FileText className="h-4 w-4" />
                        All Invoices
                    </Link>
                    <Link
                        href="/dashboard/clients"
                        className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted text-foreground"
                    >
                        <Users className="h-4 w-4" />
                        Clients
                    </Link>
                    <Link
                        href="/dashboard/settings"
                        className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted text-foreground"
                    >
                        <Settings className="h-4 w-4" />
                        Settings
                    </Link>
                </nav>
                <div className="p-4 border-t">
                    <div className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md text-muted-foreground">
                        <div className="flex-1">
                            <p className="text-foreground">{session.user?.email}</p>
                            <p className="text-xs">{session.user?.role}</p>
                        </div>
                    </div>
                    <Link
                        href="/api/auth/signout"
                        className="flex items-center gap-3 px-3 py-2 mt-2 text-sm font-medium rounded-md hover:bg-red-50 text-destructive"
                    >
                        <LogOut className="h-4 w-4" />
                        Sign Out
                    </Link>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 overflow-y-auto">
                <div className="container mx-auto p-8 max-w-6xl">
                    {children}
                </div>
            </main>
        </div>
    )
}
