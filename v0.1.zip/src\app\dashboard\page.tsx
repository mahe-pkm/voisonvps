import { prisma } from "@/lib/prisma"
import Decimal from "decimal.js"

export default async function DashboardPage() {
    // Fetch summary stats
    const invoiceCount = await prisma.invoice.count()
    const clientCount = await prisma.client.count()

    // Note: decimal.js totals handled by prisma require conversion if doing aggregation
    // For total revenue, we might need raw query or aggregation
    // Prisma aggregate returns Decimal, we can format it.

    const aggregates = await prisma.invoice.aggregate({
        _sum: {
            roundedTotal: true,
        },
        where: {
            status: "PAID"
        }
    })

    // Total Receivable (All non-draft invoices)
    const totalReceivable = await prisma.invoice.aggregate({
        _sum: { roundedTotal: true },
        where: { status: { not: "DRAFT" } }
    })

    // Total Received (All payments)
    const totalReceived = await prisma.payment.aggregate({
        _sum: { amount: true }
    })

    const receivableAmount = new Decimal(totalReceivable._sum.roundedTotal || 0)
    const receivedAmount = new Decimal(totalReceived._sum.amount || 0)
    const pendingAmount = receivableAmount.sub(receivedAmount)

    return (
        <div className="space-y-6">
            <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <div className="p-6 bg-card rounded-xl border shadow-sm">
                    <h3 className="text-sm font-medium text-muted-foreground">Total Revenue</h3>
                    <p className="text-2xl font-bold mt-2">
                        ₹ {receivedAmount.toString()}
                    </p>
                </div>
                <div className="p-6 bg-card rounded-xl border shadow-sm">
                    <h3 className="text-sm font-medium text-muted-foreground">Pending Amount</h3>
                    <p className="text-2xl font-bold mt-2 text-orange-600">
                        ₹ {pendingAmount.toString()}
                    </p>
                </div>
                <div className="p-6 bg-card rounded-xl border shadow-sm">
                    <h3 className="text-sm font-medium text-muted-foreground">Invoices</h3>
                    <p className="text-2xl font-bold mt-2">{invoiceCount}</p>
                </div>
                <div className="p-6 bg-card rounded-xl border shadow-sm">
                    <h3 className="text-sm font-medium text-muted-foreground">Clients</h3>
                    <p className="text-2xl font-bold mt-2">{clientCount}</p>
                </div>
            </div>

        </div>
    )
}
