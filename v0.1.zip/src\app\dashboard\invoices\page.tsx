import { prisma } from "@/lib/prisma"
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Plus, Eye, FileText } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ShareButton } from "@/components/ShareButton"
import { InvoiceActions } from "./InvoiceActions"

import { getCurrentProfileId } from "@/lib/currentProfile"

export default async function InvoicesPage() {
    const currentProfileId = await getCurrentProfileId()

    // Force weak consistency check
    const invoices = await prisma.invoice.findMany({
        where: {},
        include: { client: true },
        orderBy: { createdAt: "desc" },
    })

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold tracking-tight">Invoices</h2>
                <Link href="/dashboard/invoices/new">
                    <Button>
                        <Plus className="mr-2 h-4 w-4" /> New Invoice
                    </Button>
                </Link>
            </div>

            <div className="rounded-md border bg-card">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Invoice #</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Client</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {invoices.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
                                    No invoices found.
                                </TableCell>
                            </TableRow>
                        ) : (
                            invoices.map((inv: any) => {
                                // Serialize Decimal objects to string for Client Component
                                const invoice = {
                                    ...inv,
                                    subtotal: inv.subtotal.toString(),
                                    taxTotal: inv.taxTotal.toString(),
                                    totalAmount: inv.totalAmount.toString(),
                                    roundedTotal: inv.roundedTotal.toString(),
                                    client: {
                                        ...inv.client,
                                        openingBalance: inv.client.openingBalance ? inv.client.openingBalance.toString() : "0"
                                    }
                                }

                                return (
                                    <TableRow key={invoice.id}>
                                        <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                                        <TableCell>{format(invoice.issueDate, "dd MMM yyyy")}</TableCell>
                                        <TableCell>{invoice.client.name}</TableCell>
                                        <TableCell>
                                            <span className="px-2 py-1 rounded-full text-xs font-semibold bg-secondary">
                                                {invoice.status}
                                            </span>
                                        </TableCell>
                                        <TableCell className="text-right font-mono">
                                            ₹ {invoice.roundedTotal.toString()}
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <InvoiceActions
                                                invoice={invoice}
                                                appUrl={process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}
                                            />
                                        </TableCell>
                                    </TableRow>
                                )
                            })
                        )}
                    </TableBody>
                </Table>
            </div>
        </div>
    )
}
