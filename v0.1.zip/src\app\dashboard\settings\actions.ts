"use server"

import { prisma } from "@/lib/prisma"
import { CompanyProfileData } from "@/lib/companyProfile"
import { revalidatePath } from "next/cache"

export async function updateCompanyProfile(data: CompanyProfileData) {
    // Upsert logic (though we assume seed ran)
    // Actually we can just findFirst and update, or upsert with fixed ID if we had one.
    // Since we don't know the ID, we findFirst.

    const existing = await prisma.companyProfile.findFirst()

    const payload = {
        name: data.name,
        address: data.address,
        state: data.state,
        gstin: data.gstin,
        bankName: data.bankDetails.name,
        bankBranch: data.bankDetails.branch,
        bankAccountNo: data.bankDetails.accountNo,
        bankIfsc: data.bankDetails.ifsc,
        sealUrl: data.sealUrl,
        signatureUrl: data.signatureUrl,
        upiQrUrl: data.upiQrUrl,
        logoUrl: data.logoUrl,
        paymentTerms: data.paymentTerms,
        termsAndConditions: data.termsAndConditions
    }

    if (existing) {
        await prisma.companyProfile.update({
            where: { id: existing.id },
            data: payload
        })
    } else {
        await prisma.companyProfile.create({
            data: payload
        })
    }

    revalidatePath("/dashboard/settings")
    revalidatePath("/bill") // Invalidate public bills? Ideally specific paths but this is tricky.
    // We trust that fetching fresh data in components handles it, but cached pages needs revalidation.
}
